export interface Employee {
    name: string
    age: number
    city: string
}